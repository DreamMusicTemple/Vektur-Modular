// VekturModularApp.swift — standalone application shell. Hosts the same
// VekturModularAudioUnit the AUv3 extension exposes, in-process.
import SwiftUI
import VekturEngine
import VekturUI

@main
struct VekturModularApp: App {
    @State private var engine = StandaloneAudioEngine()
    @State private var midi = MIDIInputService()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            RootView(engine: engine)
                .task {
                    // MIDI first: its virtual source receives the unit's MIDI out.
                    midi.start(eventList: nil, schedule: nil)
                    engine.midiOutputBlock = midi.makeOutputBlock()
                    await engine.start()
                    connectMIDI()
                }
        }
        // Phase 8: any screen in its own window (Stage Manager, external display, Mac).
        WindowGroup("Vektur Modular", id: "screen", for: Screen.self) { $screen in
            if let au = engine.audioUnit {
                ScreenContent(screen: screen ?? .rack, audioUnit: au)
                    .environment(\.panelWear, au.appearance.wear)
                    .preferredColorScheme(.dark)
            } else {
                ProgressView()
            }
        }
        .onChange(of: scenePhase) { _, phase in
            switch phase {
            case .background: engine.appDidEnterBackground()
            case .active:
                engine.appWillEnterForeground()
                connectMIDI()
            default: break
            }
        }
    }

    /// MIDI 2.0 event lists when the unit offers them, else MIDI 1.0 bytes.
    private func connectMIDI() {
        midi.start(eventList: engine.audioUnit?.scheduleMIDIEventListBlock, schedule: engine.audioUnit?.scheduleMIDIEventBlock)
    }
}

struct RootView: View {
    let engine: StandaloneAudioEngine

    var body: some View {
        Group {
            if let au = engine.audioUnit {
                MainView(audioUnit: au, engineStatus: statusText)
            } else {
                VStack(spacing: 12) {
                    ProgressView()
                    Text(statusText).font(.caption.monospaced())
                }
            }
        }
    }

    private var statusText: String {
        switch engine.status {
        case .stopped: return "stopped"
        case .starting: return "starting…"
        case .running:
            let ms = engine.sampleRate > 0 ? Double(engine.ioBufferFrames) / engine.sampleRate * 1000 : 0
            return String(format: "%.0f Hz · %d fr (%.1f ms)", engine.sampleRate, engine.ioBufferFrames, ms)
        case .interrupted: return "interrupted"
        case .failed(let msg): return "audio failed: \(msg)"
        }
    }
}
