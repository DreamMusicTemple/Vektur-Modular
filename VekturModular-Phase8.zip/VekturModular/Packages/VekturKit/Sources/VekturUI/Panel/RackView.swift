// RackView.swift — Phase 8 main rack: cabinets of module panels on
// brushed rails in a tolex case (layout from Panels.json), with patch
// cables drooping between jacks.
//
// Patching on the rack: tap an output jack, then an input jack. Tapping a
// patched input while nothing is selected removes its cable. The cables are
// the same PatchState the patch canvas edits.
import SwiftUI
import VekturAudioUnit
import VekturCore

public struct RackView: View {
    let audioUnit: VekturModularAudioUnit
    var layout: PanelLayout
    @State private var models: PanelModels
    @State private var patch: PatchState
    @State private var jacks = JackState()
    @State private var wear: Double
    @State private var moduleWear: [String: Double]
    @State private var message: String?

    public init(audioUnit: VekturModularAudioUnit, layout: PanelLayout = .standard) {
        self.audioUnit = audioUnit
        self.layout = layout
        _models = State(initialValue: PanelModels(audioUnit: audioUnit, identifiers: layout.modules.flatMap(\.parameters)))
        _patch = State(initialValue: audioUnit.currentPatch)
        _wear = State(initialValue: audioUnit.appearance.wear)
        _moduleWear = State(initialValue: audioUnit.appearance.moduleWear)
    }

    public var body: some View {
        ScrollView(.vertical) {
            VStack(alignment: .leading, spacing: 18) {
                ForEach(layout.rows) { row in cabinet(row) }
                if let message { Text(message).font(.footnote).foregroundStyle(PanelTheme.legend2).padding(.horizontal) }
            }
            .padding(.vertical, 12)
            .overlayPreferenceValue(JackAnchorKey.self) { anchors in
                GeometryReader { proxy in
                    TimelineView(.periodic(from: .now, by: 0.1)) { ctx in
                        CableLayer(patch: patch, anchors: anchors.mapValues { proxy[$0] }, opacity: patch.layout.cableOpacity,
                                   thickness: max(3, patch.layout.cableThickness), level: { audioUnit.level(ofCable: $0) },
                                   time: ctx.date.timeIntervalSinceReferenceDate)
                    }
                }
                .allowsHitTesting(false)
            }
        }
        .background(PanelTheme.room)
        .onReceive(NotificationCenter.default.publisher(for: VekturModularAudioUnit.appearanceDidChange, object: audioUnit)) { _ in
            wear = audioUnit.appearance.wear; moduleWear = audioUnit.appearance.moduleWear
        }
        .onAppear { refreshPatch() }
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Rack")
    }

    private func cabinet(_ row: PanelRow) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(row.name).font(PanelTheme.legendFont(12, weight: .semibold)).tracking(1)
                .foregroundStyle(Color(white: 0.55)).padding(.leading, 22).padding(.bottom, 6)
                .accessibilityAddTraits(.isHeader)
            ScrollView(.horizontal) {
                VStack(spacing: 0) {
                    RackRail()
                    HStack(spacing: 0) {
                        ForEach(row.modules) { m in
                            ModulePanelView(module: m, models: models, jacks: jacks, lamp: { lamp(m.key) }, onJack: jackTapped)
                                .environment(\.panelWear, moduleWear[m.key] ?? wear)
                        }
                    }
                    RackRail()
                }
                .environment(\.panelWear, wear)
                .padding(.horizontal, 18).padding(.vertical, 10)
                .background(TolexBackground().clipShape(RoundedRectangle(cornerRadius: 10)))
                .shadow(color: .black.opacity(0.7), radius: 16, y: 12)
                .padding(.horizontal, 12)
            }
            .scrollIndicators(.visible)
        }
    }

    private func lamp(_ key: String) -> Bool {
        if key.hasPrefix("lfo"), let spec = ParameterRegistry.spec(identifier: "\(key).rate") {
            let hz = Double(audioUnit.kernel.get(spec.address))
            return sin(Date().timeIntervalSinceReferenceDate * 2 * .pi * min(hz, 25)) > 0
        }
        return !audioUnit.heldNotes().isEmpty
    }

    // MARK: Patching

    private func refreshPatch() {
        patch = audioUnit.currentPatch
        jacks.patchedInputs = Set(patch.cables.map(\.to))
        jacks.patchedOutputs = Set(patch.cables.map(\.from))
    }

    private func jackTapped(_ ref: PortRef, _ isInput: Bool) {
        guard let armed = jacks.armed else {
            if isInput, let c = patch.cables.first(where: { $0.to == ref }), !c.locked {
                var p = patch; p.cables.removeAll { $0.id == c.id }
                commit(p, note: "Removed \(RackCatalog.displayName(c.from, input: false)) → \(RackCatalog.displayName(c.to, input: true))")
                return
            }
            jacks.armed = ref; jacks.armedIsInput = isInput
            return
        }
        jacks.armed = nil
        guard armed != ref || jacks.armedIsInput != isInput else { return }
        guard jacks.armedIsInput != isInput else { message = "Connect an output to an input."; return }
        let from = isInput ? armed : ref, to = isInput ? ref : armed
        var p = patch
        p.cables.removeAll { $0.to == to && !$0.locked }
        guard let id = p.nextCableID else { message = "The patch is full (\(PatchState.maxCables) cables)."; return }
        p.cables.append(CableState(id: id, from: from, to: to))
        commit(p, note: "\(RackCatalog.displayName(from, input: false)) → \(RackCatalog.displayName(to, input: true))")
    }

    private func commit(_ p: PatchState, note: String) {
        let result = audioUnit.applyPatch(p)
        refreshPatch()
        message = result.isClean ? note : "\(note) — \(result.problems.count) cable(s) not accepted by the engine"
    }
}

/// Catenary-like cable drawing (cubic droop), colour per cable id, a soft
/// shadow, and a glow that follows the signal level.
struct CableLayer: View {
    let patch: PatchState
    let anchors: [String: CGPoint]
    var opacity: Double
    var thickness: Double
    var level: (Int) -> Float
    var time: Double
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    static let colours: [Color] = [Color(red: 0.85, green: 0.2, blue: 0.16), Color(red: 0.95, green: 0.76, blue: 0.19), Color(red: 0.18, green: 0.48, blue: 0.85),
                                   Color(red: 0.24, green: 0.65, blue: 0.35), Color(red: 0.94, green: 0.49, blue: 0.13), Color(red: 0.91, green: 0.9, blue: 0.87),
                                   Color(red: 0.61, green: 0.35, blue: 0.71), Color(white: 0.12)]

    var body: some View {
        Canvas { gc, _ in
            for c in patch.cables {
                guard let a = anchors[JackAnchorKey.id(c.from, input: false)], let b = anchors[JackAnchorKey.id(c.to, input: true)] else { continue }
                let dx = b.x - a.x, dist = hypot(dx, b.y - a.y), sag = min(180, 30 + dist * 0.35)
                var p = Path(); p.move(to: a)
                p.addCurve(to: b, control1: CGPoint(x: a.x + dx * 0.25, y: a.y + sag), control2: CGPoint(x: b.x - dx * 0.25, y: b.y + sag))
                let colour = PatchCanvasView.palette[c.colour ?? ""] ?? Self.colours[c.id % Self.colours.count]
                gc.stroke(p.offsetBy(dx: 2, dy: 4), with: .color(.black.opacity(0.35)), style: StrokeStyle(lineWidth: thickness + 2, lineCap: .round))
                let lv = Double(min(max(level(c.id) * 3, 0), 1))
                if lv > 0.02 && !reduceMotion {
                    gc.stroke(p, with: .color(colour.opacity(0.35 * lv)), style: StrokeStyle(lineWidth: thickness + 6, lineCap: .round))
                }
                gc.stroke(p, with: .color(colour.opacity(opacity)), style: StrokeStyle(lineWidth: thickness, lineCap: .round))
                for end in [a, b] { gc.fill(Path(ellipseIn: CGRect(x: end.x - 5, y: end.y - 5, width: 10, height: 10)), with: .color(Color(white: 0.1))) }
            }
        }
        .accessibilityHidden(true)
    }
}
